package BackEnd;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

@RunWith(Parameterized.class)
public class MazeTest {
    Maze maze;
    int height;
    int length;

    public MazeTest(int height, int length){
        this.height=height;
        this.length=length;
    }

    @Before
    public void setUp(){
        maze=new Maze(height, length);
    }

    @Test
    public void getHeightTest(){
        Assert.assertEquals(maze.getHeight(), height, 0);
    }

    @Test
    public void getLengthTest(){
        Assert.assertEquals(maze.getLength(), length, 0);
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void getFieldTest() {
        maze.getField(height+1, length+1);
    }

    @Parameterized.Parameters
    public static List<Object[]> parameters(){
        List<Object[]> params=new ArrayList<>();
        params.add(new Object[]{7,9});
        params.add(new Object[]{6,5});
        params.add(new Object[]{8,3});
        params.add(new Object[]{12,5});
        return params;
    }


}