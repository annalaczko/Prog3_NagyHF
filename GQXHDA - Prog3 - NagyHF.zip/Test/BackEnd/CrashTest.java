package BackEnd;

import javafx.stage.Stage;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.*;

public class CrashTest {
    Game game;
    Crash crash;
    int fieldSize;

    @Before
    public void setUp() throws IOException, ClassNotFoundException {
        game= new Game(null, null);
        game.newMazeSetUp();
        crash= new Crash(game, fieldSize);
        fieldSize=100;
    }

    @Test
    public void getSafeCoorXTest(){
        boolean value=crash.getSafeCoorX()>0&&crash.getSafeCoorX()<1365;
        Assert.assertTrue(value);
    }

    @Test
    public void getSafeCoorYTest(){
        boolean value=crash.getSafeCoorY()>0&&crash.getSafeCoorY()<1365;
        Assert.assertTrue(value);
    }

}