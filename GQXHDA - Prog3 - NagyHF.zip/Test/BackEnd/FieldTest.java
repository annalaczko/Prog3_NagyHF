package BackEnd;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class FieldTest {

    Field field;

    @Before
    public void setUp(){
        field=new Field();
    }

    @Test
    public void getTypeTest() {
        field.removeWall(Direction.east);
        field.removeWall(Direction.north);
        Assert.assertEquals(3, field.getType(),0.0);
    }
}