package GUI;

import BackEnd.Bullet;
import BackEnd.Game;
import BackEnd.Main;
import KeyEventHandlers.PressKeyHandler;
import KeyEventHandlers.ReleaseKeyHandler;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

public class GameGUI {
    private final Pane root;
    private final int fieldSize;
    private final int maxDroplet=10;
    private ArrayList<ImageView> tankView;
    private ArrayList<ImageView> playersTankView;
    private ArrayList<ImageView> dropletView;
    private ArrayList<Label> playersNameField;
    private final ArrayList<Label> playersPoints= new ArrayList<>();
    private final ArrayList<Circle> bulletsView = new ArrayList<>();
    private ImageView [] [] mazeView;
    private final Game game;
    private final Stage primaryStage;
    private final Main main;
    private final Scene gameScene;

    public class InterruptButtonHandler implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent actionEvent) {
            clearGameScene();
            game.setGameOver(true);
            game.setClosedGame(false);
            try {
                main.getMenu().start();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    public class CloseButtonHandler implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent actionEvent) {

            clearGameScene();
            game.setGameOver(true);
            game.setClosedGame(true);
            try {
                main.getMenu().start();
                main.getGameOverWindow().start();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public GameGUI(Game game, Main main, Stage primaryStage) throws IOException, ClassNotFoundException {
        this.main=main;
        this.primaryStage=primaryStage;
        this.game=game;
        fieldSize=80;
        root=backgroundLoad();
        gameScene = new Scene(root);
        if (primaryStage!=null){
            GameButton interrupt = new GameButton("Interrupt", 582, 620);
            GameButton close = new GameButton("Close", 582, 690);
            root.getChildren().addAll(interrupt, close);
            interrupt.setOnAction(new InterruptButtonHandler());
            close.setOnAction(new CloseButtonHandler());
            gameScene.setOnKeyReleased(new ReleaseKeyHandler(game));
            gameScene.setOnKeyPressed(new PressKeyHandler(game));
            setPlayerPoints();
            setPlayerNamesAndPictures();
        }
        tankImport();
        dropletImport();
    }

    public void start() throws FileNotFoundException {
        updatePlayerPoints();
        updatePlayerNames();
        if (primaryStage!=null){
            primaryStage.setScene(gameScene);
        }

    }

    private Pane backgroundLoad() throws FileNotFoundException {
        Pane root=new Pane();
        BackgroundImage background = new BackgroundImage(new Image(new FileInputStream("resources\\hattersima.png")),
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,
                BackgroundSize.DEFAULT);
        root.setBackground(new Background(background));
        root.setMaxSize(1365,768);
        root.setMinSize(1365, 768);
        root.setPrefSize(1365, 768);
        return root;
    }

    public void mazeImportLoad() throws FileNotFoundException {
        mazeView=new ImageView[game.getMaze().getHeight()][game.getMaze().getLength()];
        for (int i=0; i<game.getMaze().getHeight(); i++) {
            for (int j = 0; j < game.getMaze().getLength(); j++) {
                mazeView[i][j] = fieldImport(game.getMaze().getField(i, j).getType(), i, j);
                root.getChildren().add(mazeView[i][j]);
            }
        }
    }

    public void removeMazeView(){
        for (int i=0; i<game.getMaze().getHeight(); i++) {
            for (int j = 0; j < game.getMaze().getLength(); j++) {
                root.getChildren().removeAll(mazeView[i][j]);
                mazeView[i][j]=null;
            }
        }
    }

    public void removeTankView(int idx){
        root.getChildren().removeAll(tankView.get(idx));
    }

    public void tankLoad() {
        for ( int i=0; i<tankView.size(); i++) {
            tankView.get(i).relocate(game.getTanks().get(i).getCoorX()-fieldSize/2, game.getTanks().get(i).getCoorY()-fieldSize/2);
            tankView.get(i).setFitWidth(fieldSize);
            tankView.get(i).setFitHeight(fieldSize);
            tankView.get(i).setRotate(game.getTanks().get(i).getDirectionDegrees());
        }
        root.getChildren().addAll(tankView.get(0), tankView.get(1));
    }

    private ImageView fieldImport(int type, int i, int j) throws FileNotFoundException {
        ImageView fieldView =new ImageView( new Image(new FileInputStream("resources\\mezo"+type+".png")));
        fieldView.relocate(((1365-game.getMaze().getLength()*fieldSize)/2)+j*fieldSize,68+(500-game.getMaze().getHeight()*fieldSize)/2+i*fieldSize);
        fieldView.setFitHeight(fieldSize);
        fieldView.setFitWidth(fieldSize);
        fieldView.setPreserveRatio(true);
        return fieldView;
    }

    private void tankImport() throws FileNotFoundException{
        tankView= new ArrayList<>();
        tankView.add(new ImageView(new Image(new FileInputStream("resources\\tank0.png"))));
        tankView.add(new ImageView(new Image(new FileInputStream("resources\\tank1.png"))));
    }

    private void tankUpdate(){
        for(int i=0; i<game.getTanks().size(); i++){
            tankView.get(i).relocate(game.getTanks().get(i).getCoorX()-fieldSize/2, game.getTanks().get(i).getCoorY()-fieldSize/2);
            tankView.get(i).setRotate(game.getTanks().get(i).getDirectionDegrees());
        }
    }

    public void update(){
        tankUpdate();
        bulletUpdate();
        dropletUpdate();
    }

    private void bulletUpdate(){
        for(int i=0; i<game.getBullets().size(); i++){
            bulletsView.get(i).relocate(game.getBullets().get(i).getCoorX(), game.getBullets().get(i).getCoorY());
        }
    }

    public void bulletLoad(Bullet bullet){
        bulletsView.add(new Circle(bullet.getCoorX(), bullet.getCoorY(), bullet.getRadius()));
        root.getChildren().add(bulletsView.get(bulletsView.size()-1));
    }

    public void setPlayerNamesAndPictures() throws FileNotFoundException {
        playersNameField= new ArrayList<>();
        playerTankImport();
        for (int i =0; i<2; i++){
            playersTankView.get(i).setPreserveRatio(true);
            playersTankView.get(i).setFitHeight(150);
            playersTankView.get(i).relocate(20+i*1175, 548);
            Label name= new Label(game.getBattleData().getNames().get(i));
            name.relocate(20+i*1175, 698);
            name.setPrefSize(150, 50);
            name.setStyle("-fx-font-size:30; " +
                    "-fx-font-weight: bold; " +
                    "-fx-text-fill: #666666;  " +
                    "-fx-font: 30px Verdana");
            playersNameField.add(name);
            root.getChildren().addAll(playersTankView.get(i), playersNameField.get(i));
        }
    }

    public void updatePlayerNames(){
        playersNameField.get(0).setText(game.getBattleData().getNames().get(0));
        playersNameField.get(1).setText(game.getBattleData().getNames().get(1));
    }

    public void setPlayerPoints() throws FileNotFoundException {
        playerTankImport();
        for (int i =0; i<2; i++){
            playersPoints.add(new Label(Integer.toString(game.getBattleData().getPoints()[i])));
            playersPoints.get(i).relocate(200+i*815, 668);
            playersPoints.get(i).setPrefSize(150, 50);
            playersPoints.get(i).setStyle("-fx-font-size:30; " +
                    "-fx-font-weight: bold; " +
                    "-fx-text-fill: #666666;  " +
                    "-fx-font: 30px Verdana; text-align: center;"
            );
            root.getChildren().addAll(playersPoints.get(i));
        }
    }

    public void updatePlayerPoints() {
        for (int i =0; i<2; i++){
            playersPoints.get(i).setText(Integer.toString(game.getBattleData().getPoints()[i]));
        }
    }

    private void playerTankImport() throws FileNotFoundException {
        playersTankView = new ArrayList<>();
        playersTankView.add(new ImageView(new Image(new FileInputStream("resources\\newtank0.png"))));
        playersTankView.add(new ImageView(new Image(new FileInputStream("resources\\newtank1.png"))));
    }

    private void dropletImport() throws FileNotFoundException {
        dropletView = new ArrayList<>();
        for(int i=0; i<maxDroplet; i++) {
            dropletView.add(new ImageView(new Image(new FileInputStream("resources\\drop.png"))));
        }
    }

    public void dropletLoad() throws FileNotFoundException {
        for(int i=0; i<game.getDroplets().size(); i++) {
            root.getChildren().add(dropletView.get(i));
        }
    }

    public void removeDropletView(){
        for (int i=0; i<dropletView.size(); i++){
            root.getChildren().removeAll(dropletView.get(i));
        }
    }

    private void dropletUpdate(){
        for(int i=0; i<game.getDroplets().size(); i++){
            dropletView.get(i).relocate(game.getDroplets().get(i).getCoorX()-fieldSize/2, game.getDroplets().get(i).getCoorY()-fieldSize/2);
        }
    }

    public ArrayList<Circle> getBulletsView() {
        return bulletsView;
    }

    public Pane getRoot() {
        return root;
    }

    public void clearGameScene(){
        for (ImageView imageView : tankView) {
            root.getChildren().removeAll(imageView);
        }

        for (Circle circle : bulletsView) {
            root.getChildren().removeAll(circle);
        }
        bulletsView.clear();
        for (int i=0; i<game.getMaze().getHeight(); i++) {
            for (int j = 0; j < game.getMaze().getLength(); j++) {
                root.getChildren().removeAll(mazeView[i][j]);
                mazeView[i][j].imageProperty().setValue(null);
            }
        }
    }

    public int getFieldSize() {
        return fieldSize;
    }
}