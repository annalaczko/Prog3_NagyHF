package BackEnd;

public class Bullet {
    private double coorX;
    private double coorY;
    private double degrees;
    private final double radius;
    private final double velocity;
    private int timeToLive;
    private final Game game;
    private static int bulletsCount=0;
    private final int bullet_id;
    private final Tank tank;


    public Bullet(double x, double y, double degrees, double velocity,int tankradius, double radius, Game game, Tank tank){
        this.tank=tank;
        bullet_id=bulletsCount++;
        this.game=game;
        this.degrees=degrees;
        this.radius=radius;
        coorX=x+Math.cos(Math.toRadians(degrees)) * tankradius*1.41;
        coorY=y+Math.sin(Math.toRadians(degrees)) * tankradius*1.41;
        this.velocity=velocity;
        timeToLive=game.getBulletStandardTTL();
    }

    public void update(int diedBullets){
        move();
        game.getCrash().bulletOutOfMaze(this,diedBullets);
        timeToLive--;
        if (timeToLive==0){
            die(diedBullets);
        }
    }

    public void die(int diedBullets){
        int idx=-1;
        for (int i=0; i<game.getBullets().size(); i++){
            if (game.getBullets().get(i).getBullet_id()==bullet_id){
                idx=i;
            }
        }
        if(idx<0){
            System.out.println("HIBA BULLET.DIE()");
        }
        game.getGUI().getRoot().getChildren().removeAll(game.getGUI().getBulletsView().get(idx));
        game.getGUI().getBulletsView().remove(idx);
        game.getBullets().remove(idx);
        diedBullets++;
        tank.setBulletCount();
    }

    private void ricochet(){
        boolean [] vertical_horizontal =game.getCrash().checkBulletWallCrash((int)coorX,(int)coorY,radius);
        if (vertical_horizontal[0]&&vertical_horizontal[1]){
            degrees+=180;
        } else if(vertical_horizontal[1]){
            if (degrees==90||degrees==270){
                degrees+=180;
            } else {
                degrees*=-1;
            }
        }else if(vertical_horizontal[0]){
            if (degrees==0||degrees==180){
                degrees+=180;
            } else if(degrees<180) {
                degrees=180-degrees;
            }
        }
        if (degrees <0) degrees +=360;
        if (degrees >360) degrees -=360;
    }

    private void move(){
        for (int i=0; i<velocity; i++) {
            coorX += Math.cos(Math.toRadians(degrees));
            coorY += Math.sin(Math.toRadians(degrees));
            ricochet();
        }

    }

    public int getBullet_id() {
        return bullet_id;
    }

    public double getRadius() {
        return radius;
    }

    public double getCoorX() {
        return coorX;
    }

    public double getCoorY() {
        return coorY;
    }
}