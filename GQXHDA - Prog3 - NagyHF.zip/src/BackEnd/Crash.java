package BackEnd;

import java.util.ArrayList;
import java.util.Random;

public class Crash {
    private final int mazeCoorXbegin;
    private final int mazeCoorYbegin;
    private final int mazeCoorXend;
    private final int mazeCoorYend;
    private final int fieldSize;
    private final Game game;
    private ArrayList<SolidWall> walls;

    public Crash(Game game, int fieldSize){
        this.game=game;
        this.fieldSize=fieldSize;
        mazeCoorXbegin=(1365-game.getMaze().getLength()*fieldSize)/2;
        mazeCoorYbegin=68+(500-game.getMaze().getHeight()*fieldSize)/2;
        mazeCoorXend=1362-mazeCoorXbegin;
        mazeCoorYend=765-mazeCoorYbegin+68-200;
        initWalls();
    }

    public void removeSolidWalls(){
        walls.clear();
    }

    private void initWalls(){
        int type;
        walls= new ArrayList<>();
        for (int i=0; i<game.getMaze().getHeight(); i++){
            for (int j=0; j<game.getMaze().getLength(); j++){
                type=game.getMaze().getField(i,j).getType();

                if (type /8==1){
                    for (int width=0; width<3; width++) {
                        for (int x = 0; x < fieldSize; x++) {
                            walls.add(new SolidWall(x+mazeCoorXbegin+j*fieldSize, mazeCoorYbegin+fieldSize*i+width));
                        }
                    }
                    type-=8;
                }

                if (type /4==1){
                    for (int y = 0; y < fieldSize; y++) {
                        for (int width=0; width<3; width++) {
                            walls.add(new SolidWall(mazeCoorXbegin+fieldSize*(j+1)-width-1, mazeCoorYbegin+fieldSize*i+y));
                        }
                    }
                    type-=4;
                }

                if (type /2==1){
                    for (int width=0; width<3; width++) {
                        for (int x = 0; x < fieldSize; x++) {
                            walls.add(new SolidWall(x+mazeCoorXbegin+fieldSize*j, mazeCoorYbegin+fieldSize*(i+1)-width-1));
                        }
                    }
                    type-=2;
                }

                if (type==1){
                    for (int y = 0; y < fieldSize; y++) {
                        for (int width=0; width<3; width++) {
                            walls.add(new SolidWall(mazeCoorXbegin+fieldSize*j+width, mazeCoorYbegin+fieldSize*i+y));
                        }
                    }
                    type-=1;
                }

                if(type!=0){
                    System.out.println("Baj van, crashel a Crash");
                }

            }
        }
    }

    public boolean checkTankWallCrash(double x, double y, int tanksize){
        for(SolidWall wall: walls){
            if( reachedTank(x,y,tanksize,wall.getCoorX(), wall.getCoorY())){
                return true;
            }
        }
        return false;
    }

    public boolean [] checkBulletWallCrash(double x, double y, double radius){ //
        boolean [] xy=new boolean[2];
        int xint=(int) x, yint=(int) y;
        for(SolidWall wall: walls){
            xy[0]= Math.abs(x - wall.getCoorX()) < radius && yint == wall.getCoorY();
            xy[1]= Math.abs(y - wall.getCoorY()) < radius && xint == wall.getCoorX();
            if(xy[0]||xy[1]){
                return xy;
            }
        }
        return xy;
    }

    public void checkHitByBullet(int tanksize){
        int tank=-1, bullet=-1;
        for(int i=0; i<game.getTanks().size(); i++){
            for(int j=0; j<game.getBullets().size(); j++){
                if(reachedTank(game.getTanks().get(i).getCoorX(),game.getTanks().get(i).getCoorY(),tanksize, game.getBullets().get(j).getCoorX(), game.getBullets().get(j).getCoorY())){
                    tank=i;
                    bullet=j;
                }
            }
        }
        if (tank>-1){
            game.getTanks().get(tank).die();
            game.getBullets().get(bullet).die(0);
        }
    }

    public void bulletOutOfMaze(Bullet b, int diedBullets){
        if (b.getCoorX()>mazeCoorXend||b.getCoorX()<mazeCoorXbegin||b.getCoorY()>mazeCoorYend|| b.getCoorY()<mazeCoorYbegin){
            b.die(diedBullets);
        }
    }

    private boolean reachedTank(double tankX, double tankY, int tanksize, double x, double y){
        return Math.abs(tankX - x) < tanksize / 2 && Math.abs(tankY - y) < tanksize / 2;
    }

    public void dropletReached(Tank tank, int tanksize){
        for (Droplet droplet: game.getDroplets()){
            if (reachedTank(tank.getCoorX(),tank.getCoorY(),tanksize,droplet.getCoorX(), droplet.getCoorY())){
                tank.setBonus(droplet.getBonus());
                droplet.die();
            }
        }

    }

    public int getSafeCoorX(){
        return new Random().nextInt(game.getMaze().getLength())*fieldSize+fieldSize/2+mazeCoorXbegin;
    }

    public int getSafeCoorY(){
        return new Random().nextInt(game.getMaze().getHeight())*fieldSize+fieldSize/2+mazeCoorYbegin;
    }
}