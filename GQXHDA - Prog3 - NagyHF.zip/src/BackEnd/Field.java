package BackEnd;

public class Field {
    private boolean n;
    private boolean e;
    private boolean s;
    private boolean w;

    public Field() {
        n=true; e=true; s=true; w=true;
    }

    public void removeWall(Direction wall) {
        switch(wall) {
            case north:
                n = false;
                break;
            case east:
                e = false;
                break;
            case south:
                s = false;
                break;
            case west:
                w = false;
                break;
            default:
                break;
        }
    }

    public int getType(){
        int type=0;
        if (getWall(Direction.north))  type+=8;
        if (getWall(Direction.east))  type+=4;
        if (getWall(Direction.south))    type+=2;
        if (getWall(Direction.west)) type+=1;
        return type;
    }

    public boolean getWall(Direction wall) {
        return switch (wall) {
            case north -> n;
            case east -> e;
            case south -> s;
            case west -> w;
        };
    }
}