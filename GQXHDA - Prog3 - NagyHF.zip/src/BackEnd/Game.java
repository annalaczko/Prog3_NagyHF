package BackEnd;

import Files.BattleData;
import Files.TankFile;
import GUI.GameGUI;
import javafx.animation.AnimationTimer;
import javafx.stage.Stage;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class Game {
    private Maze maze;
    private Crash crash;
    private static GameGUI GUI;
    private final ArrayList<Tank>tanks;
    private final ArrayList<Bullet> bullets;
    private final ArrayList<Droplet> droplets;
    private AnimationTimer timer;
    private final int bulletStandardTTL;
    private int playersAlive;
    private boolean isGameOver;
    private boolean closedGame;
    private BattleData battleData;
    private int waitingTime;

    public Game(Main main, Stage primaryStage) throws IOException, ClassNotFoundException {
        tanks= new ArrayList<>();
        bullets= new ArrayList<>();
        droplets= new ArrayList<>();
        battleData= new BattleData("jaj","juj",0,0);
        bulletStandardTTL=800;
        GUI=new GameGUI(this, main, primaryStage);
    }

    public void start() throws Exception {
        tanks.add(new Tank(this,0));
        tanks.add(new Tank(this, 1));
        newMazeSetUp();
        GUI.updatePlayerPoints();
        int dropletsCount = 2;
        for (int i = 0; i< dropletsCount; i++){
            droplets.add(new Droplet(this));
        }
        GUI.dropletLoad();
        newTanksSetUp();
        GUI.start();
        isGameOver=false;
        timer=new AnimationTimer() {
            @Override
            public void handle(long l) {
                try {
                    if (isGameOver){
                        timer.stop();
                        gameOver();
                    } else {
                        update();
                        if (playersAlive<2) {
                            if (waitingTime>0){
                                waitingTime--;
                            }else{
                                if (playersAlive == 1) {
                                    battleData.winFor(tankAliveID());
                                    GUI.removeTankView(tankAliveID());
                                }
                                GUI.removeMazeView();
                                removeBullets();
                                newMazeSetUp();
                                dropletsReset();
                                newTanksSetUp();
                                GUI.updatePlayerPoints();
                            }
                        }

                    }
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        timer.start();

    }

    public void playerDies(int player_id){
        switch (playersAlive){
            case 2:
                GUI.removeTankView(player_id);
                break;
            case 1:
                GUI.removeTankView(tankAliveID());
                break;
            default:
                //HIBA
                break;
        }
        playersAlive--;
    }

    private void update() {

        for (Tank tank : tanks) {
            tank.update();
        }

        int diedBullets=0;
        for (int i=0;i<bullets.size(); i++ ) { //itt kozben lehet hogy fogy a bullet szám és az megzavarja
            bullets.get(i-diedBullets).update(diedBullets);
        }
        crash.checkHitByBullet(GUI.getFieldSize()/5*2);
        GUI.update();
    }

    private void spawn(){
        tanks.get(0).setCoorX(crash.getSafeCoorX());
        tanks.get(0).setCoorY(crash.getSafeCoorY());
        tanks.get(1).setCoorX(crash.getSafeCoorX());
        tanks.get(1).setCoorY(crash.getSafeCoorY());
    }

    private void gameOver() throws IOException, ClassNotFoundException {
        tanks.clear();
        GUI.removeDropletView();
        droplets.clear();
        crash.removeSolidWalls();
        if (battleData.getPoints()[0]!=0 || battleData.getPoints()[1]!=0) {
            if(closedGame){
                ArrayList<BattleData> closedBattleData = TankFile.loadClosedBattleData();
                closedBattleData.add(battleData);
                TankFile.saveClosedBattleData(closedBattleData);
            } else {
                TankFile.saveUnclosedBattle(battleData);
            }
        }
        GUI.removeMazeView();
    }

    public void newMazeSetUp() throws FileNotFoundException{
        int height= new Random().nextInt(4)+4;
        int length= new Random().nextInt(9)+6;
        maze=new Maze(height, length);
        GUI.mazeImportLoad();
        crash=new Crash(this, 80);

        waitingTime=100;
    }

    private void newTanksSetUp() {
        spawn();
        GUI.tankLoad();
        tanks.get(0).setAlive(true);
        tanks.get(1).setAlive(true);
        playersAlive=2;
    }

    private void dropletsReset() throws FileNotFoundException {
        GUI.removeDropletView();
        for (Droplet droplet: droplets){
            droplet.die();
        }
        GUI.dropletLoad();
    }

    private void removeBullets(){
        while(bullets.size()>0){
            bullets.get(0).die(0);
        }
    }

    private int tankAliveID(){
        if(tanks.get(0).isAlive()) return 0;
        if(tanks.get(1).isAlive()) return 1;
        return 7;
    }

    public void setBattleData(BattleData battleData) {
        this.battleData = battleData;
    }

    public ArrayList<Bullet> getBullets() {
        return bullets;
    }

    public ArrayList<Tank> getTanks() {
        return tanks;
    }

    public int getBulletStandardTTL() {
        return bulletStandardTTL;
    }

    public Crash getCrash() {
        return crash;
    }

    public static GameGUI getGUI() {
        return GUI;
    }

    public Maze getMaze() {
        return maze;
    }

    public void setGameOver(boolean gameOver) {
        isGameOver = gameOver;
    }

    public void setClosedGame(boolean closedGame) {
        this.closedGame = closedGame;
    }

    public BattleData getBattleData() {
        return battleData;
    }

    public ArrayList<Droplet> getDroplets() {
        return droplets;
    }
}