package BackEnd;

import java.util.Random;

public class Maze {
    private final int height;
    private final int length;
    private final Field[] [] fields;
    private final boolean [] [] availableFields;

    public Maze(int height, int length){
        this.height = height;
        this.length = length;
        fields = new Field[height] [length];
        availableFields =new boolean[height][length];
        for(int i = 0; i< height; i++){
            for (int j = 0; j< length; j++) {
                fields[i] [j]= new Field();
                availableFields[i][j]=false;
            }
        }
        int i=0;
        int j=0;
        int idx=0;
        while (unavailableFields()!=0){
            while (availableFields[i][j]) {
                idx++;
                if (idx>= height * length ||idx<0) return;
                i=indexToI(idx);
                j=indexToJ(idx);
            }
            if (j==0) {
                if (i!=0) {
                    fields[i-1][0].removeWall(Direction.south);
                    fields[i][0].removeWall(Direction.north);
                }
            } else {
                fields[i][j-1].removeWall(Direction.east);
                fields[i][j].removeWall(Direction.west);
            }
            pathfinder(i, j);
        }
    }

    private void pathfinder(int i, int j){
        int step=0;
        boolean stepAllowed;
        while (!availableFields[i][j]){
            stepAllowed=false;
            availableFields[i][j]=true;
            while (!stepAllowed) {
                step = new Random().nextInt(4);
                stepAllowed = (i > 0 || step != 0) && (i != height - 1 || step != 2) && (j > 0 || step != 3) && (j != length - 1 || step != 1);
            }
            switch (step){
                case 0:
                    fields[i][j].removeWall(Direction.north);
                    i--;
                    fields[i][j].removeWall(Direction.south);
                    break;
                case 1:
                    fields[i][j].removeWall(Direction.east);
                    j++;
                    fields[i][j].removeWall(Direction.west);
                    break;
                case 2:
                    fields[i][j].removeWall(Direction.south);
                    i++;
                    fields[i][j].removeWall(Direction.north);
                    break;
                case 3:
                    fields[i][j].removeWall(Direction.west);
                    j--;
                    fields[i][j].removeWall(Direction.east);
                    break;
                default:
                    break;


            }

        }
    }

    private int unavailableFields(){
        int db=0;
        for (boolean [] bi: availableFields){
            for (boolean bj: bi) {
                if (!bj) db++;
            }
        }
        return db;
    }

    private int indexToI(int idx){
        return idx/ length;
    }

    private int indexToJ(int idx){
        return  idx% length;
    }

    public Field getField(int i, int j){
        return fields[i][j];
    }

    public int getHeight() {
        return height;
    }

    public int getLength() {
        return length;
    }
}