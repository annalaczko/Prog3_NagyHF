package BackEnd;

import java.util.Random;

public class Droplet {
    private int coorX;
    private int coorY;
    private double bonus;
    private final Game game;

    public Droplet(Game game){
        this.game=game;
        coorX=game.getCrash().getSafeCoorX();
        coorY=game.getCrash().getSafeCoorY();
        bonus=new Random().nextDouble()+1;
    }
    public void die(){
        coorX=game.getCrash().getSafeCoorX();
        coorY=game.getCrash().getSafeCoorY();
        bonus=new Random().nextDouble()+1;
    }

    public int getCoorX() {
        return coorX;
    }

    public int getCoorY() {
        return coorY;
    }

    public double getBonus() {
        return bonus;
    }
}