package BackEnd;

import java.util.Random;
import java.lang.Math;

public class Tank {
    private final int player_id;
    private double directionDegrees;
    private double coorX;
    private double coorY;
    private final double velocity;
    private final boolean [] movements;
    private final Game game;
    private boolean alive;
    private double bonus;
    private int bulletCount;

    public Tank(Game game, int player_id){
        bulletCount=1;
        alive=true;
        bonus=1.5;
        this.game=game;
        this.player_id=player_id;
        velocity=3;
        directionDegrees = new Random().nextInt(360);
        movements =new boolean[4];
    }

    public void update(){
        move();
        rotate();
    }

    public void die (){
        game.playerDies(player_id);
        alive=false;
    }

    private void move(){

        double coorXtemp=coorX, coorYtemp=coorY;
        if (movements[1]) {
            coorXtemp+=Math.cos(Math.toRadians(directionDegrees)) * velocity;
            coorYtemp+=Math.sin(Math.toRadians(directionDegrees)) * velocity;
        }
        if (movements[2]) {
            coorXtemp-=Math.cos(Math.toRadians(directionDegrees))*velocity;
            coorYtemp-=Math.sin(Math.toRadians(directionDegrees))*velocity;
        }
        boolean xy=game.getCrash().checkTankWallCrash(coorXtemp, coorYtemp, Game.getGUI().getFieldSize()/5*2);
        if (!xy) {
            coorX = coorXtemp;
            coorY = coorYtemp;
        }
        game.getCrash().dropletReached(this, Game.getGUI().getFieldSize()/5*2);
    }

    private void rotate(){
        if(movements[0]) {
            directionDegrees -= velocity*1.25;
            if (directionDegrees <0) directionDegrees +=360;
        }
        if(movements[3]) {
            directionDegrees += velocity*1.25;
            if (directionDegrees >360) directionDegrees -=360;
        }
    }

    public void shoot(){
        if (bulletCount>0){
            game.getBullets().add(new Bullet(coorX,coorY, directionDegrees,velocity*bonus, Game.getGUI().getFieldSize()/5 ,6.0/bonus, game, this));
            Game.getGUI().bulletLoad(game.getBullets().get(game.getBullets().size()-1));
            bonus=1.5;
            bulletCount--;
        }

    }

    public void setMovement(int idx, boolean value) {
        movements[idx]=value;
    }

    public void setCoorX(double coorX) {
        this.coorX = coorX;
    }

    public void setCoorY(double coorY) {
        this.coorY = coorY;
    }

    public double getCoorX() {
        return coorX;
    }

    public double getCoorY() {
        return coorY;
    }

    public double getDirectionDegrees() {
        return directionDegrees;
    }

    public void setAlive(boolean alive) {
        this.alive = alive;
    }

    public boolean isAlive() {
        return alive;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    public void setBulletCount(){
        bulletCount++;
    }
}