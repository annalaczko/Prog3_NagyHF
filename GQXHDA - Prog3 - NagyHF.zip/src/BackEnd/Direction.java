package BackEnd;

public enum Direction {
    north,
    east,
    south,
    west
}