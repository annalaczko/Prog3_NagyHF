package BackEnd;

public class SolidWall {
    private final int coorX;
    private final int coorY;

    public SolidWall(int x, int y){
        coorX=x;
        coorY=y;
    }

    public int getCoorY() {
        return coorY;
    }

    public int getCoorX() {
        return coorX;
    }
}