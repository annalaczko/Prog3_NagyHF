package Files;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

public class TankFile {
    private static final int maxUnclosedBattles=5;

    public static void updateFiles(){
        String fileName;
        Path path;
        int gap=0;
        for (int i=0; i<maxUnclosedBattles; i++){
            fileName= "saves\\unclosed" + i + ".txt";
            path= Paths.get(fileName);
            if(!Files.exists(path)){
                gap++;
            }else{
                int newI=i-gap;
                File oldFile=new File(fileName);
                File newFile=new File("saves\\unclosed" + newI + ".txt");
                if(!oldFile.renameTo(newFile)){
                }
            }
        }
    }

    public static void saveUnclosedBattle(BattleData battleData) throws IOException {
        String fileName;
        Path path;
        for (int i=0; i<maxUnclosedBattles; i++){
            fileName= "saves\\unclosed" + i + ".txt";
            path= Paths.get(fileName);
            if (!Files.exists(path)){
                ObjectOutputStream out= new ObjectOutputStream(new FileOutputStream(fileName));
                out.writeObject(battleData);
                out.close();
                return;
            }
        }
    }

    public static ArrayList<BattleData> loadAllUnclosedBattle() throws IOException, ClassNotFoundException {
        ArrayList<BattleData> allUnclosedBattle= new ArrayList<>();
        String fileName;
        Path path;
        for (int i=0; i<maxUnclosedBattles; i++){
            fileName= "saves\\unclosed" + i + ".txt";
            path= Paths.get(fileName);
            if (Files.exists(path)){
                ObjectInputStream in=new ObjectInputStream(new FileInputStream(fileName));
                allUnclosedBattle.add((BattleData) in.readObject());
                in.close();
            }
        }
        return allUnclosedBattle;
    }

    public static ArrayList<BattleData> loadClosedBattleData() throws IOException, ClassNotFoundException {
        String fileName= "saves\\closedbattles.txt";
        if (new File(fileName).length()==0){
            return new ArrayList<>();
        }
        ObjectInputStream in=new ObjectInputStream(new FileInputStream(fileName));
        ArrayList<BattleData> ab=(ArrayList<BattleData>) in.readObject();
        in.close();
        return ab;
    }

    public static void saveClosedBattleData(ArrayList<BattleData> closedBattleData) throws IOException {
        String fileName= "saves\\closedbattles.txt";
        ObjectOutputStream out= new ObjectOutputStream(new FileOutputStream(fileName));
        out.writeObject(closedBattleData);
        out.close();
    }

    public static void clearClosedBattleData() throws FileNotFoundException {
        String fileName= "saves\\closedbattles.txt";
        PrintWriter writer = new PrintWriter(fileName);
        writer.close();
    }

    public static void deleteUnclosedBattle(int idx){
        String fileName= "saves\\unclosed" + idx + ".txt";
        File file= new File(fileName);
        if(!file.delete()){
            System.out.println("Deleting file failed");
        }
        updateFiles();
    }

    public static ArrayList<String> unclosedBattlesToString() throws IOException, ClassNotFoundException {
        ArrayList<BattleData>allUnclosedBattle=TankFile.loadAllUnclosedBattle();
        ArrayList<String> stringArrayList=new ArrayList<>();
        for(BattleData b: allUnclosedBattle){
            stringArrayList.add(b.getNames().get(0)+" - "+b.getNames().get(1)+"       "+b.getPoints()[0]+" - "+b.getPoints()[1]);
        }
        return stringArrayList;
    }

    public static ArrayList<String> closedBattlesToString() throws IOException, ClassNotFoundException {
        ArrayList<BattleData> ALB=loadClosedBattleData();
        ArrayList<String> stringArrayList=new ArrayList<>();
        for (BattleData b: ALB){
            stringArrayList.add(b.getNames().get(0)+" - "+b.getNames().get(1)+"       "+b.getPoints()[0]+" - "+b.getPoints()[1]);
        }
        return stringArrayList;
    }
}