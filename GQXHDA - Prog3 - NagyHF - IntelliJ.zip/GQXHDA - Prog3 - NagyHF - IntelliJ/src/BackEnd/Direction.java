package BackEnd;

/**
 * Enum for placing walls to a Field
 */

public enum Direction {
    north,
    east,
    south,
    west
}